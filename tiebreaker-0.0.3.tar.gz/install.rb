#!/usr/bin/ruby

class INSTALLER

	def initialize(tiebreakerfile: "tiebreaker-0.0.3.gem", dir: "/opt/dd")
		@version = tiebreakerfile.split("-")[1].split(".gem")[0]
		@tiebreakerfile = tiebreakerfile
		@dir = dir
		@gem_path = ENV["GEM_HOME"]
		if @gem_path.class.name == "NilClass" then
			 genv = `gem environment`
			 genv.split("\n").each do |elem|
			 	if elem.include?("INSTALLATION DIRECTORY: ") then
			 		@gem_path = elem.split("INSTALLATION DIRECTORY: ")[1]
			 	end
			 end

		end
		createdirs() if install_gem() 
	end

	def createdirs()
		if ! system("mkdir -p #{@dir}") then 
			if ! File.directory?("#{@dir}/tiebreaker") then
				return false
			end
		end
		system("rm #{@dir}/tiebreaker") if File.realdirpath("#{@dir}/tiebreaker").include?("#{@gem_path}/gems/tiebreaker-") 
		system("rm #{@dir}/tiebreaker-#{@version}") if File.realdirpath("#{@dir}/tiebreaker-#{@version}").eql?("#{@gem_path}/gems/tiebreaker-#{@version}")
		return false if ! system("ln -s #{@gem_path}/gems/tiebreaker-#{@version} #{@dir}/tiebreaker-#{@version}") 
		return false if ! system("ln -s #{@dir}/tiebreaker-#{@version} #{@dir}/tiebreaker") 
		return true
	end

	def install_gem()
		 system("gem install #{@tiebreakerfile}") ? true : false
	end

end # end class

if ARGV.count == 0 then
	INSTALLER.new() 
elsif  ARGV.count == 1 
	INSTALLER.new(tiebreakerfile:ARGV[0]) 
elsif  ARGV.count == 2 
	INSTALLER.new(tiebreakerfile:ARGV[0],dir:ARGV[1]) 
else
	puts "Errors in parameter settings."
	puts "Usage:"
	puts "./installer.rb for installing tiebreaker-0.0.3.gem to /opt/dd"
	puts "./installer.rb tiebreaker-0.0.x.gem for installing tiebreaker-0.0.x.gem to /opt/dd"
	puts "./installer.rb tiebreaker-0.0.x.gem for installing tiebreaker-0.0.x.gem to /destination_path"
end
